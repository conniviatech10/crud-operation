<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel crud Opertaion</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 50%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #04AA6D;
  color: white;
}
</style>
    </head>
     <body>
        <a href="todo_create"  >Add Record</a><br></br> <br></br>
        <?php echo e(session('msg')); ?>


        <div class="flex-center position-ref full-height">

        <Table id = "customers">
            <tr>
            <td>Id</td>
            <td>Name</td>
            <td>Created At </td>
            <td>Updated At </td>
            <td colspan="2"  style="text-align:center">Action</td>
            
            </tr>
        
            <?php $__currentLoopData = $todoArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($todo->id); ?></td>
            <td><?php echo e($todo->name); ?></td>
            <td><?php echo e($todo->created_at); ?> </td>
            <td><?php echo e($todo->updated_at); ?> </td>
             
            <td><a href="todo_delete/<?php echo e($todo->id); ?> "> Delete </a></td>
            <td><a href="todo_edit/<?php echo e($todo->id); ?> "> Edit </a></td>
             </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </Table>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\todo\resources\views/todo_show.blade.php ENDPATH**/ ?>